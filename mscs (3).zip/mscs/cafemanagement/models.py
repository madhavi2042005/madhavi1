from django.db import models

# Create your models here.
class menu_items(models.Model):
    name= models.CharField(max_length=100)
    sprice= models.FloatField()
    lprice= models.FloatField()
    img= models.ImageField(upload_to="pics")
    
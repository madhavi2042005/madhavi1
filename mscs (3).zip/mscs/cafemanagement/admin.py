from django.contrib import admin
from .models import menu_items
# Register your models here.
admin.site.register(menu_items)
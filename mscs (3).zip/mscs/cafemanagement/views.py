from django.shortcuts import render

from .models import menu_items
# Create your views here.
def index(request):
    menus=menu_items.objects.all()
    return render(request,'index.html',{"menus":menus})
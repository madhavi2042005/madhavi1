from django.apps import AppConfig


class CafemanagementConfig(AppConfig):
    name = 'cafemanagement'

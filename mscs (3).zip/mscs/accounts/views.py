from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import RegisterForm

# Create your views here.
def logout(request):
    auth.logout(request)
    return redirect("/")

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            return redirect("/")
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = RegisterForm()
    return render(request, "registration/register.html", {"form": form})

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("/")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request, "registration/login.html", {"form": form})

def register(request):
    if request.method=="POST":
        username=request.POST['username']
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        email=request.POST['email']
        password1=request.POST['password1']
        password2=request.POST['password2']
        if  password1==password2:
            if User.objects.filter(username=username).exists() or User.objects.filter(email=email).exists():
                print("user already exists! or email already taken")
                messages.info(request,"user already exists or email already taken")
                return redirect("/accounts/register")
            else:
                user=User.objects.create_user(username=username,last_name=lastname,first_name=firstname,email=email,password=password1)
                user.save()
                print("user created")
                return redirect("/")
        else:
            print("password mismatches")
            messages.info(request,"password mismatches")
            return redirect("/accounts/register")
    else:
        return render(request,"register.html")